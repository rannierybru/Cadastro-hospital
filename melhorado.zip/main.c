/*******************************************************************************
Autor:Ranniery bruno
Data:05/04/2026
Arquivo:main.c, contém a função printf,scanf,do,switch e while
paciente.h, contém ifndef,define,typedef struct,time.h,stuct tm,void,int e char
paciente.c, contém if,strlen,for,else,else if,printf,scanf,strcmp,strcpy,mktime
*******************************************************************************/
#include <stdio.h>
#include "paciente.h"
int main() {
    int op;
    do {
    printf("\n==== MENU ====\n");
    printf("1-Cadastrar\n");
    printf("2-Nome crescente\n");
    printf("3-Nome decrescente\n");
    printf("4-por origem\n");
    printf("5-Por data\n");
    printf("6-Por medico\n");
    printf("7-Buscar nome\n");
    printf("8-Buscar cpf\n");
    printf("9-Buscar médico\n");
    printf("0-Sair\n");
    
    scanf("%d", &op);
    
    switch(op){
        case 1: cadastrar();break;
        case 2: listar_nome_crescente();break;
        case 3: listar_nome_decrescente();break;
        case 4: listar_origem();break;
        case 5: listar_data();break;
        case 6: listar_medico();break;
        case 7: buscar_nome();break;
        case 8: buscar_cpf();break;
        case 9: buscar_medico();break;
    }
    }while(op!=0);

    return 0;
}
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "paciente.h"

Paciente pacientes[MAX];
int total = 0;

int validarCPF(char *cpf){
    if (strlen(cpf)!= 11) return 0;//"strlen" conta quantos caracteres tem
    int i, soma = 0, resto;// i=contador do loop, soma acumula calculo
    for (i = 0;i < 9;i++)
    soma += (cpf[i] - '0') * (10-i);//cpf[i] - '0' tira o numero de asci
    resto = (soma*10)%11;
    if(resto == 10) resto = 0;
    if(resto != (cpf[9] - '0'))return 0;
    soma = 0;
    for (i = 0; i < 10; i++)
    soma += (cpf[i] - '0') * (11-i);
    resto = (soma * 10)%11;
    if(resto == 10)resto = 0;
    return resto == (cpf[10] - '0');
}
void mostrar_origem(int origem){
    if(origem==1)
    printf("sistema público");
    else if(origem==2)
    printf("sistema privado");
    else if(origem==3)
    printf("plano de saùde");
    else if(origem==4)
    printf("outros convênios");
    else
    printf("opção inválida");
}
void cadastrar(){
    if(total >= MAX){
    printf("limite atingido\n");
    return;
}
Paciente p;
printf("ID:");
scanf("%d",&p.id);

printf("Digite o nome:");
scanf(" %[^\n]", p.nome);//( %[^\n] serve para ler o nome com espaço

printf("Digite o cpf:");
scanf("%s", p.cpf);

if(!validarCPF(p.cpf)){
    printf("CPF inválido\n");
    return;
}
printf("Qual origem (1-4):");
scanf("%d", &p.origem);

time_t t = time(NULL);//pega tempo atual
p.data_horario = *localtime(&t);//converte para data

printf("Médico:");
scanf(" %[^\n]", p.medico);

printf("Descrição:");
scanf(" %[^\n]", p.descricao);

pacientes[total++] = p;
printf("feito Cadastro!\n");
}
void ordenar_nome(){
for (int i = 0;i < total - 1;i++){
    int menor = i;
    for (int j = i + 1; j < total; j++){
        if(strcmp(pacientes[j].nome, pacientes[menor].nome) < 0)//strcmp compara string
        menor = j;
    }
    
    Paciente temp = pacientes[i];
    pacientes[i] = pacientes[menor];
    pacientes[menor] = temp;
}
}
void quicksortnome(int ini, int fim){
    int i = ini, j = fim;
    char guarda[40];
    strcpy(guarda, pacientes[(ini+fim)/2].nome);
    while(i <= j){
        while(strcmp(pacientes[i].nome, guarda) < 0)i++;
        while(strcmp(pacientes[j].nome, guarda) > 0)j--;
        if (i <= j){
            Paciente temp = pacientes[i];
            pacientes[i] = pacientes[j];
            pacientes[j] = temp;
            i++; j--;
        }
    }
    if (ini < j) quicksortnome(ini,j);
    if (i < fim) quicksortnome(i,fim);
}

void listar_nome_crescente(){
    ordenar_nome();
    for (int i = 0;i < total;i++){
        printf(" \n%s |CPF: %s", pacientes[i].nome, pacientes[i].cpf);
    }
}

void listar_nome_decrescente(){
    quicksortnome(0, total-1);
    for(int i = total-1;i >= 0;i--){
        printf(" \n%s | CPF:%s", pacientes[i].nome, pacientes[i].cpf);
    }
}

void listar_origem(){
    ordenar_nome();
    for(int i = 0; i < total;i++) {
        printf("\nOrigem:%d | Nome: %s", pacientes[i].nome);
        mostrar_origem(pacientes[i].origem);
    }
}
void listar_data(){
    ordenar_nome();
    for(int i=0;i < total;i++){
        for(int j = i+1;j < total;j++){
            if(mktime(&pacientes[i].data_horario)<mktime(&pacientes[j].data_horario)){//mktime
                Paciente temp = pacientes[i];
                pacientes[i] = pacientes[j];
                pacientes[j] = temp;
            }
        }
    }
    for(int i = 0;i < total; i++){
        printf("\n%s-%02d/%02d/%d",
        pacientes[i].nome,
        pacientes[i].data_horario.tm_mday,
        pacientes[i].data_horario.tm_mon + 1,//+1, pois tm_mon começa do zero.
        pacientes[i].data_horario.tm_year + 1900);//+1900, pois tm_year começa desde 1900
    }
}
void listar_medico(){
    ordenar_nome();
    for(int i = 0;i < total;i++){
        printf("\nMedico:%s | Paciente:%s",
        pacientes[i].medico,
        pacientes[i].nome);
    }
}
void buscar_nome(){
    char nome[40];
    scanf(" %[^\n]", nome);
    for(int i = 0;i < total;i++){
        if(strcmp(nome,pacientes[i].nome)== 0){
            printf("\n%s | CPF:%s", pacientes[i].nome, pacientes[i].cpf);
        }
    }
}
void buscar_cpf(){
    char cpf[12];
    scanf("%s",cpf);
    
    for(int i = 0;i < total;i++){
        if(strcmp(cpf,pacientes[i].cpf)==0){
            printf("\nPaciente:%s", pacientes[i].nome);
        }
    }
}
void buscar_medico(){
    char medico[40];
    scanf(" %[^\n]", medico);
    for(int i = 0;i < total;i++){
        if(strcmp(medico, pacientes[i].medico)==0){
            printf("\nPaciente: %s", pacientes[i].nome);
        }
    }
    
}
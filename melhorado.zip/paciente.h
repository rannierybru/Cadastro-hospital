
#ifndef PACIENTE_H//ifndef
#define PACIENTE_H//

#include <time.h>

#define MAX 100

typedef struct paciente{
    int id;
    char nome[40];
    char cpf[12];
    int origem;
    struct tm data_horario;
    char medico[40];
    char descricao[200];
}Paciente;

void cadastrar();
void listar_nome_crescente();
void listar_nome_decrescente();
void listar_origem();
void listar_data();
void listar_medico();

void buscar_nome();
void buscar_cpf();
void buscar_medico();

int validarCPF(char *cpf);

#endif
